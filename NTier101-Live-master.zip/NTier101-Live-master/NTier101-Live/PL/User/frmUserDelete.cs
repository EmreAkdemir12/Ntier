﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NTier101_Live.PL.User
{
    public partial class frmUserDelete : Form
    {
        public frmUserDelete()
        {
            InitializeComponent();
        }
    }
}
